/**33. Programa una función que valide que un texto sea un nombre válido, p.e. miFuncion (“Javier
Ferrer”) devolverá verdadero. NOTA: No puede haber números ni caracteres especiales como
¡ o ¿
 */
"use strict"
{
    //name test function
    function testName(name) {
        //FIX SPECIAL CHARACTERS LATER
        let regex = /[^0-9]/i;

        /*if (regex.test(name)) {
            return true;
        }else{
            return false;
        }*/
       return (regex.test(name));
    }

    console.log(testName("Javier Perez"));
    console.log(testName("1v1ct0r"));

}