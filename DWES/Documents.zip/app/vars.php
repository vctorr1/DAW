<?php

$bodyOutput = '';
$arrayResultados = [];
$arrayCriterios = [];